Fixture, an Unreal fixture pack.
